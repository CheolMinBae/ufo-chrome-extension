import initialState from '../../demoData/sellers.json';

const sellersReducer = (state = initialState) => {
  return state;
};
export { sellersReducer };
