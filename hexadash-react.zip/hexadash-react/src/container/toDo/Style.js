import Styled from 'styled-components';

const TodoStyle = Styled.div`
    @media only screen and (max-width: 575px){
        margin-top: 10px;
    }
  .ant-card-head{
      margin-bottom: 10px;
  }
`;

export { TodoStyle };
