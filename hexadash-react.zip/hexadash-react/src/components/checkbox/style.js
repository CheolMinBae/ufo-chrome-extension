import { Checkbox } from 'antd';
import Styled from 'styled-components';

const CheckboxStyle = Styled(Checkbox)`

`;

export { CheckboxStyle };
