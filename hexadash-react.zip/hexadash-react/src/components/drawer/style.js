import { Drawer } from 'antd';
import Styled from 'styled-components';

const DrawerStyle = Styled(Drawer)`

`;

export { DrawerStyle };
