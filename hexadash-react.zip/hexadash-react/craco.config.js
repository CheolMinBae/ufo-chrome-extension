require = require('esm')(module);
module.exports = require('./customize-cra-config.js');